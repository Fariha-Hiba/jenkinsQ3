package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	// WebDriver declaration
	static WebDriver driver;

	// Constructor
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	// Locators
	By usernameBox = By.name("username");
	By passwordBox = By.name("password");
	By loginBtn = By.className("orangehrm-login-button");

	// Login Page Methods

	// Enter username
	public void enterUsername(String username) {
		driver.findElement(usernameBox).sendKeys(username);
	}

	// Enter password
	public void enterPassword(String password) {
		driver.findElement(passwordBox).sendKeys(password);
	}

	// Click login button
	public void clickLoginButton() {
		driver.findElement(loginBtn).click();
	}

}
