package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LandingPage {
	// WebDriver declaration
	static WebDriver driver;

	// Constructor
	public LandingPage(WebDriver driver) {
		this.driver = driver;
	}

	// Locators
	By profileName = By.className("oxd-userdropdown-name");

	// Landing Page Methods

	// Is user's profile name displayed after login?
	public boolean isUserProfileNameDisplayed() {
		boolean userProfileNamePresent;
		try {
			userProfileNamePresent = driver.findElement(profileName).isDisplayed();
			System.out.println("Login successful.");
		} catch (Exception e) {
			System.out.println("Login unsuccessful.");
			userProfileNamePresent = false;
		}
		return userProfileNamePresent;

	}

}
