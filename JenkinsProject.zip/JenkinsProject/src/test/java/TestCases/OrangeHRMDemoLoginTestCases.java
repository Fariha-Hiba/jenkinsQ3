package TestCases;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pages.LandingPage;
import Pages.LoginPage;

public class OrangeHRMDemoLoginTestCases {

	// Declaration
	static WebDriver driver;
	LoginPage login;
	LandingPage landing;
	ExtentReports extentreports;
	ExtentTest test;

	//Extent Reports Generation
	@BeforeSuite()
	public void generateExtentReports() {
		ExtentSparkReporter htmlReporter = new ExtentSparkReporter("./ExtentReports/OrangeHRMLoginTest.html");
		extentreports = new ExtentReports();
		extentreports.attachReporter(htmlReporter);
		test = extentreports.createTest("OrangeHRM Login Test");
	}

	//Open URL
	@BeforeTest
	public void openURL() {
		// Set up WebDriver
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// Instantiating Login and Landing Page
		login = new LoginPage(driver);
		landing = new LandingPage(driver);

		// Open URL
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

	}

	//Quit driver
	@AfterTest
	public void quitDriver() {
		extentreports.flush();
		driver.quit();
	}

	//Perform login and check if logged in successfully.
	@Test
	public void loginTest() {

		login.enterUsername("Admin");
		login.enterPassword("admin123");
		login.clickLoginButton();
		try {
			Assert.assertTrue(landing.isUserProfileNameDisplayed());
			test.pass("Logged into OrangeHRM Demo successfully.");
		}

		catch (AssertionError e) {
			test.fail("Login unsuccessful. Check username or password. - " + e.getMessage());
			throw e;
		}
	}
}
